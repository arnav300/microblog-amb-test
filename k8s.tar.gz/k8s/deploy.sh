docker build -t arnav30/microblog:latest -f Dockerfile .

docker push arnav30/microblog:latest


